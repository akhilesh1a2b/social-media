# Snap-It-MERN

## Visit Snap-It: https://snap-it-vaibhav.web.app/
## Youtube Video: https://youtu.be/psdz7IJ4OCs

### Snap-It is a social media app based on MERN stack having various features:
1) Create/Delete your account
2) Post images in feed with hide likes/comments feature
3) Like/comment on posts
3) Update your profile/password with email otp authentication
5) Follow/Unfollow other users to visit their profile
6) Chat with your friends
   and many more...

### 📌 Technonologies used
Technologies used are react-js, node-js, express-js, mongodb, redux, firebase, axios, bcrypt, cors, jwt, mui, formik-yup, socket-io etc.

